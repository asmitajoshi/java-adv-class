/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.javatunes.catalog;

import static java.util.stream.Collectors.*;
import static org.junit.Assert.*;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.junit.Before;
import org.junit.Test;

public class PartitioningGroupingTest {
  
  private Collection<MusicItem> allMusicItems;
  
  @Before
  public void setUp() {
    Catalog catalog = new InMemoryCatalog();
    allMusicItems = catalog.getAll();
  }
  
  /**
   * TASK: partition MusicItems into self-titled albums (artist = title), and all others.
   * 
   * RESULT:
   *  true    List<MusicItem>[6,7]
   *  false   List<MusicItem>[1,2,3,4,5,8,9,10,11,12,13,14,15,16,17,18]
   */
  @Test
  public void testPartitionBySelfTitled() {
    Map<Boolean,List<MusicItem>> itemMap = allMusicItems.stream()
      .collect(partitioningBy(item -> item.getArtist().equals(item.getTitle())));
    
    // all partition maps have exactly two entries, one of the entries might contain an empty List
    assertEquals(2, itemMap.size());
    
    List<MusicItem> trueList = itemMap.get(true);
    List<MusicItem> falseList = itemMap.get(false);
    
    assertEquals(2, trueList.size());
    assertEquals(16, falseList.size());
    
    // A neat JUnit technique
    // Recall that Collection has a forEach(Consumer) method
    // However, this isn't testing your code, it just verifies that partitioningBy works correctly (it better!)
    trueList.forEach(item -> assertTrue(item.getArtist().equals(item.getTitle())));
    falseList.forEach(item -> assertFalse(item.getArtist().equals(item.getTitle())));
    
    // convenient way to dump a Map to stdout
    dumpMap(itemMap);
  }
  
  /**
   * TASK: partition MusicItems by price <= 14.00.
   * 
   * RESULT:
   *  true   List<MusicItem>[1,7,8,13,16,17,18]
   *  false  List<MusicItem>[2,3,4,5,6,9,10,11,12,14,15]
   */
  @Test
  public void testPartitionByPrice() {
    // DONE
    Map<Boolean,List<MusicItem>> itemMap = allMusicItems.stream()
      .collect(partitioningBy(item -> item.getPrice() <= 14.00));
    
    assertEquals(2, itemMap.size());
    
    List<MusicItem> trueList = itemMap.get(true);
    List<MusicItem> falseList = itemMap.get(false);
    
    assertEquals(7, trueList.size());
    assertEquals(11, falseList.size());
  }
  
  /**
   * TASK: partition MusicItems into ROCK+CLASSIC_ROCK, and all others. Verify.
   * 
   * RESULT:
   *  true    List<MusicItem>[8,10,12,15,16,17,18]
   *  false   List<MusicItem>[1,2,3,4,5,6,7,9,11,13,14]
   */
  @Test
  public void testPartitionByMusicCategoryRock() {
    // DONE
    Map<Boolean,List<MusicItem>> itemMap = allMusicItems.stream()
      .collect(partitioningBy(item -> item.getMusicCategory() == MusicCategory.ROCK ||
                                      item.getMusicCategory() == MusicCategory.CLASSIC_ROCK));
    
    assertEquals(7, itemMap.get(true).size());
    assertEquals(11, itemMap.get(false).size());
  }
  
  /**
   * TASK: group MusicItems by music category. Verify each entry in the map.
   * 
   * RESULT:
   *  JAZZ         null
   *  POP          List<MusicItem>[1,2,6,14]
   *  BLUES        List<MusicItem>[3,4]
   *  ALTERNATIVE  List<MusicItem>[5,9]
   *  CLASSICAL    List<MusicItem>[7]
   *  ROCK         List<MusicItem>[8,10,12,15,16,17]
   *  RAP          List<MusicItem>[11]
   *  COUNTRY      List<MusicItem>[13]
   *  CLASSIC_ROCK List<MusicItem>[18]
   */
  @Test
  public void testGroupByMusicCategory() {
    // DONE
    Map<MusicCategory,List<MusicItem>> itemMap = allMusicItems.stream()
      .collect(groupingBy(MusicItem::getMusicCategory));
    
    assertEquals(8, itemMap.size());  // 9 total MusicCategory values, but we don't sell any JAZZ items
    assertNull(itemMap.get(MusicCategory.JAZZ));  // not an empty List here, there's just no entry for JAZZ
    assertEquals(4, itemMap.get(MusicCategory.POP).size());
    assertEquals(2, itemMap.get(MusicCategory.BLUES).size());
    assertEquals(2, itemMap.get(MusicCategory.ALTERNATIVE).size());
    assertEquals(1, itemMap.get(MusicCategory.CLASSICAL).size());
    assertEquals(6, itemMap.get(MusicCategory.ROCK).size());
    assertEquals(1, itemMap.get(MusicCategory.RAP).size());
    assertEquals(1, itemMap.get(MusicCategory.COUNTRY).size());
    assertEquals(1, itemMap.get(MusicCategory.CLASSIC_ROCK).size());
  }
  
  /**
   * TASK: group MusicItems by price and verify.
   * 
   * RESULT:
   *  13.99 List<MusicItem>[1,8]
   *  14.99 List<MusicItem>[2,3,5]
   *  17.97 List<MusicItem>[4,6,9,10,14]
   *   9.97 List<MusicItem>[7]
   *  16.97 List<MusicItem>[11]
   *  18.97 List<MusicItem>[12,15]
   *  11.97 List<MusicItem>[13,16,17,18]
   */
  @Test
  public void testGroupByPrice() {
    // DONE
    Map<Double,List<MusicItem>> itemMap = allMusicItems.stream()
      .collect(groupingBy(MusicItem::getPrice));
    
    assertEquals(2, itemMap.get(13.99).size());
    assertEquals(3, itemMap.get(14.99).size());
    assertEquals(5, itemMap.get(17.97).size());
    assertEquals(1, itemMap.get( 9.97).size());
    assertEquals(1, itemMap.get(16.97).size());
    assertEquals(2, itemMap.get(18.97).size());
    assertEquals(4, itemMap.get(11.97).size());    
  }
  
  /*
   * Helper method to dump map to standard out. Map is assumed to have entries with Collections.
   */
  private static void dumpMap(Map<?,? extends Collection<?>> map) {
    map.entrySet().forEach(System.out::println);
    System.out.println();
    
    // Map.forEach() takes a BiConsumer<K,V>. This block lambda is passed key-value pairs each iteration.
    map.forEach((key, list) -> {
      System.out.println(key);
      list.forEach(System.out::println);
    });
  }
}