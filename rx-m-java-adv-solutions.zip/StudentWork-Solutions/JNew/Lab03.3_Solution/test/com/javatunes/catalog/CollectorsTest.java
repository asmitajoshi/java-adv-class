/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.javatunes.catalog;

import static java.util.Comparator.*;
import static java.util.stream.Collectors.*;
import static org.junit.Assert.*;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.Before;
import org.junit.Test;

public class CollectorsTest {
  
  private Collection<MusicItem> allMusicItems;
  
  @Before
  public void setUp() {
    Catalog catalog = new InMemoryCatalog();
    allMusicItems = catalog.getAll();
  }
  
	@Test
	public void testCollectorsDefaultImpl() {
	  // DONE: obtain a List of music categories via Collectors.toList() and print the name of the List impl class
	  List<MusicCategory> categoryList = allMusicItems.stream()
	    .map(MusicItem::getMusicCategory)
	    .collect(toList());
	  System.out.println(categoryList.getClass().getName());
	  
	  // DONE: verify size of list via JUnit assertion
	  assertEquals(18, categoryList.size());
	  
	  
	  // DONE: obtain a Set of music categories via Collectors.toSet() and print the name of the Set impl class
	  Set<MusicCategory> categorySet = allMusicItems.stream()
	    .map(MusicItem::getMusicCategory)
	    .collect(toSet());
	  System.out.println(categorySet.getClass().getName());
	  
	  // DONE: verify size of set (hint: no duplicates)
	  assertEquals(8, categorySet.size());
	}
	
	@Test
	public void testCollectorsSpecifiedImpl() {
	  // DONE: obtain a Deque (double-ended queue, pronounced "deck") of music items, sorted by artist natural order
  	  // Use ArrayDeque as the implementation - it is a standard java.util collection
	  Deque<MusicItem> itemDeck = allMusicItems.stream()
	    .sorted(comparing(MusicItem::getArtist))
	    .collect(toCollection(ArrayDeque::new));
	  
    // DONE: verify the specified Deque impl class is being used
	  assertTrue(itemDeck instanceof ArrayDeque);
	  assertEquals(ArrayDeque.class, itemDeck.getClass());
	  
	  // DONE: verify first and last elements in the collection are what you expect (hint: see Deque API)
  	  // First artist is Aerosmith (id of 15), last artist is Yes (id of 16)
    assertEquals(Long.valueOf(15), itemDeck.getFirst().getId());  // Aerosmith
    assertEquals(Long.valueOf(16), itemDeck.getLast().getId());   // Yes
	}
	
	@Test
  public void testCollectorsReturnType() {
    // DONE: change the type of the "result" variable from Object to a more specific, more meaningful type
	  String result = allMusicItems.stream()
	    .filter(item -> item.getMusicCategory() == MusicCategory.POP)
	    .map(MusicItem::getArtist)
	    .sorted()
	    .collect(Collectors.joining("|"));
	  
	  // DONE: write a JUnit assertion to verify the result value
	  assertEquals("Annie Lennox|Peter Gabriel|Seal|Sting", result);
  }
}