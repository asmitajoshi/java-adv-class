/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package net.weather;

public class Client {

  public static void main(String[] args) {
    if (args.length == 0) {
      System.out.println("Usage: net.weather.Client <city>");
      return;
    }
    
    Newscast news = new Newscast();
    
    // super-simple implementation of Meteorologist.forecast()
    // news.playWeatherSegment(city -> "raining", "Seattle");
    
    // more complex implementation of Meteorologist.forecast()
    Meteorologist m = city -> {
      String weather;
      switch(city) {
        case "Seattle":
          weather = "raining";
          break;
        case "New York":
          weather = "variable";
          break;
        case "San Diego":
          weather = "sunny";
          break;
        default:
          throw new WeatherException("Unknown city: " + city);
          // OK to throw runtime exception, even if not declared in abstract method's throws clause:
          // throw new IllegalArgumentException("Unknown city: " + city);
      }
      return weather;
    };
    
    news.playWeatherSegment(m, args[0]);
  }
}