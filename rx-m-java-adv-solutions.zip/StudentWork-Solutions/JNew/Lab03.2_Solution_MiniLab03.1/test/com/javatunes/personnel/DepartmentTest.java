/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.javatunes.personnel;

import org.junit.Before;
import org.junit.Test;

public class DepartmentTest {

  private Department dept;
  
  @Before
  public void setUp() {
    dept = Department.getDepartment();
  }
  
  @Test
  public void testListEmployees() {
    dept.listEmployees();
  }

  @Test
  public void testWorkEmployees() {
    dept.workEmployees();
  }

  @Test
  public void testPayEmployees() {
    dept.payEmployees();
  }
}