/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.javatunes.catalog;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

public class CatalogTest {
  
  private Catalog catalog;

  @Before
  public void setUp() {
    catalog = new InMemoryCatalog();
  }
  
  @Test
  public void testFindByIdExists() {
    MusicItem item1 = catalog.findById(1L);
    assertEquals(Long.valueOf(1), item1.getId());
  }
  
  @Test
  public void testFindByIdNotExists() {
    assertNull(catalog.findById(1001L));
  }
  
  @Test
  public void testFindByKeywordExists() {
    String keyword = "an";
    Collection<MusicItem> items = catalog.findByKeyword(keyword);
    // sort the results by id (for testing purposes)
    List<MusicItem> sortedItems = new ArrayList<>(items);
    sortedItems.sort(null);  // natural order (id)
    // 1, 3, 4, 7, 9, 12, 17
    assertEquals(7, sortedItems.size());
    assertEquals(Long.valueOf(1),  sortedItems.get(0).getId());
    assertEquals(Long.valueOf(3),  sortedItems.get(1).getId());
    assertEquals(Long.valueOf(4),  sortedItems.get(2).getId());
    assertEquals(Long.valueOf(7),  sortedItems.get(3).getId());
    assertEquals(Long.valueOf(9),  sortedItems.get(4).getId());
    assertEquals(Long.valueOf(12), sortedItems.get(5).getId());
    assertEquals(Long.valueOf(17), sortedItems.get(6).getId());
  }
  
  @Test
  public void testFindByKeywordNotExists() {
    String keyword = "NOT FOUND";
    assertEquals(0, catalog.findByKeyword(keyword).size());
  }
  
  @Test
  public void testFindByCategoryExists() {
    Collection<MusicItem> items = catalog.findByCategory(MusicCategory.BLUES);
    // sort the results by id (for testing purposes)
    List<MusicItem> sortedItems = new ArrayList<>(items);
    sortedItems.sort(null);  // natural order (id)
    // 3, 4
    assertEquals(2, sortedItems.size());
    assertEquals(Long.valueOf(3), sortedItems.get(0).getId());
    assertEquals(Long.valueOf(4), sortedItems.get(1).getId());
  }
  
  @Test
  public void testFindByCategoryNotExists() {
    assertEquals(0, catalog.findByCategory(MusicCategory.JAZZ).size());
  }
}